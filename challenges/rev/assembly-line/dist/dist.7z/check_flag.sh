#!/bin/bash

###########################################
#                                         #
#              Assembly Line              #
#                 Shu Ting                #
#                   1980                  #
#                                         #
#         In time's assembly line         #
#       Night presses against night.      #
#   We come off the factory night-shift   #
#    In line as we march towards home.    #
#         Over our heads in a row         #
#        The assembly line of stars       #
#        Stretches across the sky.        #
#         Beside us, little trees         #
#      Stand numb in assembly lines.      #
#                                         #
#       The stars must be exhausted       #
#         After thousands of years        #
#     Of journeys which never change.     #
#      The little trees are all sick,     #
#       Choked on smog and monotony,      #
#    Stripped of their color and shape.   #
#     It's not hard to feel for them;     #
#   We share the same tempo and rhythm.   #
#                                         #
#    Yes, I'm numb to my own existence    #
#     as if, like the trees and stars     #
#        —perhaps just out of habit       #
#       —perhaps just out of sorrow,      #
#        I'm unable to show concern       #
#      For my own manufactured fate.      #
#                                         #
###########################################

# place your input here, it will NOT follow the flag format and is restricted to ^[a-zA-Z0-9_/.,-]+$
inp="[REDACTED]"

a=""
for (( i=0; i<${#inp}; i++ )); do
  c="${inp:$i:1}"
  printf -v b '%d' "'$c"
  a+="$b "
done

[[ "$(echo "${a}1 i" | ./workers/worker_0 | ./workers/worker_1 | ./workers/worker_2 | ./workers/worker_3 | ./workers/worker_4 | ./workers/worker_5 | ./workers/worker_6 | ./workers/worker_7 | ./workers/worker_8 | ./workers/worker_9 | ./workers/worker_10 | ./workers/worker_11 | ./workers/worker_12 | ./workers/worker_13 | ./workers/worker_14 | ./workers/worker_15 | ./workers/worker_16 | ./workers/worker_17 | ./workers/worker_18 | ./workers/worker_19 | ./workers/worker_20 | ./workers/worker_21 | ./workers/worker_22 | ./workers/worker_23 | ./workers/worker_24 | ./workers/worker_25 | ./workers/worker_26 | ./workers/worker_27 | ./workers/worker_28 | ./workers/worker_29 | ./workers/worker_30 | ./workers/worker_31 | ./workers/worker_32 | ./workers/worker_33 | ./workers/worker_34 | ./workers/worker_35 | ./workers/worker_36 | ./workers/worker_37 | ./workers/worker_38 | ./workers/worker_39 | ./workers/worker_40 | ./workers/worker_41 | ./workers/worker_42 | ./workers/worker_43 | ./workers/worker_44 | ./workers/worker_45 | ./workers/worker_46 | ./workers/worker_47 | ./workers/worker_48 | ./workers/worker_49 | ./workers/worker_50 | ./workers/worker_51 | ./workers/worker_52 | ./workers/worker_53 | ./workers/worker_54 | ./workers/worker_55 | ./workers/worker_56 | ./workers/worker_57 | ./workers/worker_58 | ./workers/worker_59 | ./workers/worker_60 | ./workers/worker_61 | ./workers/worker_62 | ./workers/worker_63 | ./workers/worker_64 | ./workers/worker_65 | ./workers/worker_66 | ./workers/worker_67 | ./workers/worker_68 | ./workers/worker_69 | ./workers/worker_70 | ./workers/worker_71 | ./workers/worker_72 | ./workers/worker_73 | ./workers/worker_74 | ./workers/worker_75 | ./workers/worker_76 | ./workers/worker_77 | ./workers/worker_78 | ./workers/worker_79 | ./workers/worker_80 | ./workers/worker_81 | ./workers/worker_82 | ./workers/worker_83 | ./workers/worker_84 | ./workers/worker_85 | ./workers/worker_86 | ./workers/worker_87 | ./workers/worker_88 | ./workers/worker_89 | ./workers/worker_90 | ./workers/worker_91 | ./workers/worker_92 | ./workers/worker_93 | ./workers/worker_94 | ./workers/worker_95 | ./workers/worker_96 | ./workers/worker_97 | ./workers/worker_98 | ./workers/worker_99)" == *' 1 i' ]] && printf 'The product is satisfactory.\n' || printf 'The product is unsatisfactory.\n'
