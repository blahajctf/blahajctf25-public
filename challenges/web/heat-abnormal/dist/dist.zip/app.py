from pickle import MARK, UNICODE, DICT, STOP, load 
from io import BytesIO
from os import urandom
from flask import Flask, request, render_template

import __main__

app = Flask(__name__)
app.config['SECRET_KEY'] = 'blahaj{test_flag}'

def build_creds(username, msg):
    creds = MARK
    creds += UNICODE + b'username\n' + UNICODE + username.encode() + b'\n'
    creds += UNICODE + b'message\n' + UNICODE + msg.encode() + b'\n'
    creds += DICT
    creds += STOP
    try:
        cred_data = load(BytesIO(creds)) 
        return cred_data
    except Exception as e:
        return {'username': 'error!', 'password': 'error!'}

@app.route('/message', methods=['GET', 'POST'])
def message():
    if request.method == 'POST':
        username = request.form['username']
        msg = request.form['message']
        user = build_creds(username, msg)
        return render_template('toll.html')
    return render_template('message.html')

@app.route('/healthz', methods=['GET'])
def healthcheck():
    return "OK"

if __name__ == '__main__':
    app.run(debug=True)
